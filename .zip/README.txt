To publish this to the web:
# the host dir that must must be kept in sync with the GitHub repo is ..\\Portfolio
- Make changes with Godot
- Export PCK only (or if exporting whole project will have to make changes to index.html for the custom loading and progress page)
- Run the upload .bat file
